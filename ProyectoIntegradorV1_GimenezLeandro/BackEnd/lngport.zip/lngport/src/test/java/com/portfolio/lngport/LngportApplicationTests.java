package com.portfolio.lngport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LngportApplicationTests {

	@Test
	void contextLoads() {
	}

}
